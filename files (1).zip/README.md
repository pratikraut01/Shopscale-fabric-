# 🏗️ ShopScale Fabric — Event-Driven Microservices E-Commerce Platform

> **Internship Project** | Full Stack Java Developer Domain  
> Built by **Pratik Raut** | [GitHub](https://github.com/pratikraut01) | [LinkedIn](https://www.linkedin.com/in/pratik-raut123)

---

## 📋 Project Overview

ShopScale Fabric is a **production-grade, event-driven microservices** e-commerce marketplace.  
Designed to handle high-traffic scenarios (Black Friday scale) with **asynchronous communication**, **fault tolerance**, and **high availability**.

---

## 🏛️ Architecture

```
┌─────────────┐     JWT      ┌──────────────────┐
│   React JS  │ ──────────► │   API Gateway    │ :8080
│  Frontend   │             │  Rate Limit 100/m │
└─────────────┘             └────────┬─────────┘
                                     │ Route
              ┌──────────────────────┼──────────────────────┐
              ▼                      ▼                      ▼
    ┌─────────────────┐   ┌─────────────────┐   ┌──────────────────┐
    │ Product Service │   │  Order Service  │   │Inventory Service │
    │   MongoDB       │   │  PostgreSQL     │   │  Kafka Consumer  │
    │   :8081         │   │  :8082          │   │  :8083           │
    └─────────────────┘   └────────┬────────┘   └──────────────────┘
                                   │ Kafka
                                   ▼ OrderPlacedEvent
                          ┌─────────────────────┐
                          │    Apache Kafka      │
                          │  (Message Broker)    │
                          └──────┬──────────┬───┘
                                 │          │
                    ┌────────────┘          └────────────┐
                    ▼                                    ▼
         ┌──────────────────┐               ┌──────────────────────┐
         │ Inventory Service│               │ Notification Service  │
         │  Stock Update    │               │   Email Confirm       │
         └──────────────────┘               └──────────────────────┘

    ┌───────────────┐    ┌──────────────┐    ┌───────────────┐
    │ Eureka Server │    │    Zipkin    │    │  PostgreSQL   │
    │  Discovery    │    │  Tracing     │    │  + MongoDB    │
    │  :8761        │    │  :9411       │    │  Databases    │
    └───────────────┘    └──────────────┘    └───────────────┘
```

---

## ⚡ Key Features

| Feature | Implementation |
|---|---|
| Event-Driven Architecture | Apache Kafka — OrderPlacedEvent |
| Service Discovery | Netflix Eureka Server |
| API Gateway | Spring Cloud Gateway |
| JWT Authentication | Token validation + relay |
| Rate Limiting | 100 requests/min per IP |
| Circuit Breaker | Resilience4j |
| Distributed Tracing | Zipkin + Spring Sleuth |
| Containerization | Docker + Docker Compose |
| SAGA Pattern | Foundation implemented |
| Fault Tolerance | Kafka message persistence |

---

## 🛠️ Technology Stack

| Layer | Technology |
|---|---|
| Backend | Java 17, Spring Boot 3.2 |
| Frontend | React JS 18 |
| Messaging | Apache Kafka |
| Database | PostgreSQL (Orders), MongoDB (Products) |
| Service Registry | Netflix Eureka |
| API Gateway | Spring Cloud Gateway |
| Security | JWT (JJWT) |
| Resilience | Resilience4j Circuit Breaker |
| Tracing | Zipkin + Micrometer |
| Containerization | Docker, Docker Compose |

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose installed
- Git

### Run the Project

```bash
# 1. Clone the repository
git clone https://github.com/pratikraut01/shopscale-fabric.git
cd shopscale-fabric

# 2. Start ALL services (one command!)
docker-compose up --build

# 3. Wait ~2-3 minutes for all services to start
```

### Access the Application

| Service | URL |
|---|---|
| 🌐 Frontend (React) | http://localhost:3000 |
| 🚪 API Gateway | http://localhost:8080 |
| 🗂️ Eureka Dashboard | http://localhost:8761 |
| 🔍 Zipkin Tracing | http://localhost:9411 |
| 📦 Product API | http://localhost:8080/api/products |
| 🛒 Order API | http://localhost:8080/api/orders |
| 🏭 Inventory API | http://localhost:8080/api/inventory |

---

## 📁 Project Structure

```
shopscale-fabric/
├── docker-compose.yml         ← Start everything here!
├── README.md
│
├── frontend/                  ← React JS UI
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Dashboard.js   ← Architecture overview
│   │   │   ├── Products.js    ← Product CRUD
│   │   │   ├── Orders.js      ← Place orders (triggers Kafka)
│   │   │   └── Inventory.js   ← Stock management
│   │   ├── services/api.js    ← Axios API calls
│   │   └── App.js             ← Router + Layout
│   ├── Dockerfile
│   └── nginx.conf
│
├── api-gateway/               ← Spring Cloud Gateway + JWT
├── eureka-server/             ← Service Registry
├── product-service/           ← MongoDB CRUD
├── order-service/             ← PostgreSQL + Kafka Producer
├── inventory-service/         ← Kafka Consumer (stock update)
└── notification-service/      ← Kafka Consumer (email)
```

---

## 🔄 Event Flow (How it Works)

```
1. Client places order via React Frontend
2. API Gateway validates JWT token
3. Order Service saves order to PostgreSQL
4. Order Service publishes OrderPlacedEvent to Kafka topic "order-placed"
5. Inventory Service (consumer) → decrements stock
6. Notification Service (consumer) → sends confirmation email
7. Even if Inventory Service is DOWN → event persists in Kafka and processes on restart!
```

---

## 📡 API Endpoints

### Products (via Gateway → :8080)
```
GET    /api/products           - Get all products
POST   /api/products           - Create product
GET    /api/products/{id}      - Get by ID
PUT    /api/products/{id}      - Update product
DELETE /api/products/{id}      - Delete product
GET    /api/products/search?name=laptop
GET    /api/products/category/{category}
```

### Orders
```
GET    /api/orders             - Get all orders
POST   /api/orders             - Place order (triggers Kafka event!)
GET    /api/orders/{orderNum}  - Get by order number
GET    /api/orders/customer/{id}
```

### Inventory
```
GET    /api/inventory          - Get all stock
GET    /api/inventory/{productId}
POST   /api/inventory/{productId}/add?quantity=50
```

---

## 🧪 Test the Kafka Flow

```bash
# 1. Create a product
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"Laptop","description":"Gaming Laptop","category":"Electronics","price":45000,"stock":100}'

# 2. Place an order (this triggers Kafka event!)
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "cust-001",
    "customerEmail": "pratik@example.com",
    "totalAmount": 45000,
    "items": [{"productId":"<PRODUCT_ID>","productName":"Laptop","quantity":1,"price":45000}]
  }'

# 3. Check Inventory Service logs - stock auto-updated!
docker logs inventory-service

# 4. Check Notification Service logs - email confirmation!
docker logs notification-service
```

---

## 🎯 Architecture Patterns Implemented

- ✅ **Event-Driven Architecture (EDA)**
- ✅ **SAGA Pattern Foundation** (distributed transactions)
- ✅ **Circuit Breaker Pattern** (Resilience4j)
- ✅ **API Gateway Pattern** (centralized routing)
- ✅ **Service Discovery Pattern** (Eureka)
- ✅ **Token Relay Pattern** (JWT downstream)
- ✅ **Rate Limiting** (100 req/min/IP)
- ✅ **Distributed Tracing** (Zipkin)
- ✅ **Containerization** (Docker Compose)

---

## 👨‍💻 Author

**Pratik Raut** — Full Stack Java Developer (Internship)  
🔗 [github.com/pratikraut01](https://github.com/pratikraut01)  
🔗 [linkedin.com/in/pratik-raut123](https://www.linkedin.com/in/pratik-raut123)
