import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Products from './pages/Products';
import Orders from './pages/Orders';
import Inventory from './pages/Inventory';

const navItems = [
  { path: '/', label: '🏠 Dashboard', exact: true },
  { path: '/products', label: '🛒 Products' },
  { path: '/orders', label: '📦 Orders' },
  { path: '/inventory', label: '🏭 Inventory' },
];

const styles = {
  app: { display: 'flex', minHeight: '100vh' },
  sidebar: { width: 220, background: '#1a1a2e', color: '#fff', display: 'flex', flexDirection: 'column', flexShrink: 0 },
  sidebarHeader: { padding: '1.5rem 1.2rem', borderBottom: '1px solid rgba(255,255,255,0.08)' },
  logo: { fontWeight: 900, fontSize: '1.2rem', color: '#fff', lineHeight: 1.2 },
  logoSub: { fontSize: '0.7rem', color: '#a5b4fc', marginTop: 4, letterSpacing: '0.08em', textTransform: 'uppercase' },
  nav: { padding: '1rem 0', flex: 1 },
  navLink: (active) => ({
    display: 'block', padding: '0.7rem 1.2rem', color: active ? '#fff' : 'rgba(255,255,255,0.55)',
    textDecoration: 'none', fontSize: '0.88rem', fontWeight: active ? 600 : 400,
    background: active ? 'rgba(99,102,241,0.3)' : 'transparent',
    borderLeft: active ? '3px solid #6366f1' : '3px solid transparent',
    transition: 'all 0.2s'
  }),
  footer: { padding: '1rem 1.2rem', borderTop: '1px solid rgba(255,255,255,0.08)', fontSize: '0.7rem', color: 'rgba(255,255,255,0.3)' },
  main: { flex: 1, overflow: 'auto', background: '#f0f2f5' },
  topbar: { background: '#fff', borderBottom: '1px solid #e2e8f0', padding: '0.8rem 2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  topbarTitle: { fontWeight: 700, fontSize: '0.95rem', color: '#1a1a2e' },
  topbarBadge: { background: '#ede9fe', color: '#4f46e5', borderRadius: 6, padding: '3px 10px', fontSize: '0.75rem', fontWeight: 600 }
};

function Sidebar() {
  const location = useLocation();
  return (
    <div style={styles.sidebar}>
      <div style={styles.sidebarHeader}>
        <div style={styles.logo}>ShopScale<br/>Fabric</div>
        <div style={styles.logoSub}>Microservices Platform</div>
      </div>
      <nav style={styles.nav}>
        {navItems.map(item => {
          const active = item.exact ? location.pathname === item.path : location.pathname.startsWith(item.path);
          return (
            <Link key={item.path} to={item.path} style={styles.navLink(active)}>
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div style={styles.footer}>
        © 2024 Pratik Raut<br />Internship Project
      </div>
    </div>
  );
}

function Layout({ children }) {
  return (
    <div style={styles.app}>
      <Sidebar />
      <div style={styles.main}>
        <div style={styles.topbar}>
          <div style={styles.topbarTitle}>🏗️ Event-Driven Microservices Architecture</div>
          <div style={styles.topbarBadge}>✅ All Services Running</div>
        </div>
        {children}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/products" element={<Products />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/inventory" element={<Inventory />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
