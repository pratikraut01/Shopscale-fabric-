import React, { useState, useEffect } from 'react';
import { productAPI, orderAPI, inventoryAPI } from '../services/api';

const styles = {
  page: { padding: '2rem' },
  title: { fontSize: '1.8rem', fontWeight: 800, marginBottom: 6, color: '#1a1a2e' },
  sub: { color: '#666', marginBottom: '2rem', fontSize: '0.95rem' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '1.2rem', marginBottom: '2.5rem' },
  card: (color) => ({ background: color, borderRadius: 14, padding: '1.5rem', color: '#fff' }),
  cardNum: { fontSize: '2.5rem', fontWeight: 900, lineHeight: 1 },
  cardLabel: { fontSize: '0.85rem', opacity: 0.85, marginTop: 6 },
  archBox: { background: '#fff', borderRadius: 14, padding: '1.8rem', boxShadow: '0 2px 12px rgba(0,0,0,0.07)', marginBottom: '1.5rem' },
  archTitle: { fontWeight: 700, fontSize: '1.1rem', marginBottom: '1.2rem', color: '#1a1a2e' },
  flow: { display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0 },
  node: (color) => ({ background: color, color: '#fff', borderRadius: 10, padding: '0.7rem 1rem', fontSize: '0.82rem', fontWeight: 600, textAlign: 'center', minWidth: 110 }),
  arrow: { color: '#94a3b8', fontSize: '1.3rem', padding: '0 0.3rem' },
  serviceGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '0.8rem', marginTop: '1rem' },
  serviceChip: { background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 10, padding: '0.9rem', fontSize: '0.82rem' },
  serviceName: { fontWeight: 700, marginBottom: 3 },
  servicePort: { color: '#4f46e5', fontFamily: 'monospace', fontSize: '0.78rem' }
};

export default function Dashboard() {
  const [stats, setStats] = useState({ products: 0, orders: 0 });

  useEffect(() => {
    Promise.all([productAPI.getAll(), orderAPI.getAll()])
      .then(([p, o]) => setStats({ products: p.data.length, orders: o.data.length }))
      .catch(() => {});
  }, []);

  const services = [
    { name: 'Eureka Server', port: ':8761', color: '#7c3aed' },
    { name: 'API Gateway', port: ':8080', color: '#2563eb' },
    { name: 'Product Service', port: ':8081', color: '#0891b2' },
    { name: 'Order Service', port: ':8082', color: '#059669' },
    { name: 'Inventory Service', port: ':8083', color: '#d97706' },
    { name: 'Notification Service', port: ':8084', color: '#dc2626' },
    { name: 'Zipkin Tracing', port: ':9411', color: '#4f46e5' },
    { name: 'Kafka Broker', port: ':9092', color: '#0f172a' },
  ];

  return (
    <div style={styles.page}>
      <div style={styles.title}>🏗️ ShopScale Fabric</div>
      <div style={styles.sub}>Event-Driven Microservices E-Commerce Platform · Internship Project</div>

      <div style={styles.grid}>
        <div style={styles.card('#4f46e5')}>
          <div style={styles.cardNum}>{stats.products}</div>
          <div style={styles.cardLabel}>Total Products</div>
        </div>
        <div style={styles.card('#059669')}>
          <div style={styles.cardNum}>{stats.orders}</div>
          <div style={styles.cardLabel}>Orders Placed</div>
        </div>
        <div style={styles.card('#d97706')}>
          <div style={styles.cardNum}>6</div>
          <div style={styles.cardLabel}>Microservices Running</div>
        </div>
        <div style={styles.card('#0891b2')}>
          <div style={styles.cardNum}>✓</div>
          <div style={styles.cardLabel}>Kafka Events Active</div>
        </div>
      </div>

      <div style={styles.archBox}>
        <div style={styles.archTitle}>⚡ Event Flow (Kafka)</div>
        <div style={styles.flow}>
          <div style={styles.node('#4f46e5')}>Client</div>
          <div style={styles.arrow}>→</div>
          <div style={styles.node('#2563eb')}>API Gateway<br/><small>JWT · Rate Limit</small></div>
          <div style={styles.arrow}>→</div>
          <div style={styles.node('#059669')}>Order Service<br/><small>PostgreSQL</small></div>
          <div style={styles.arrow}>→</div>
          <div style={styles.node('#ea580c')}>Apache Kafka<br/><small>OrderPlacedEvent</small></div>
          <div style={styles.arrow}>→</div>
          <div style={styles.node('#0891b2')}>Inventory<br/><small>Stock Update</small></div>
        </div>
        <div style={{ marginTop: 10, marginLeft: 'calc(4 * 110px + 4 * 1.9rem)' }}>
          <div style={styles.arrow}>↘</div>
          <div style={{ ...styles.node('#dc2626'), display: 'inline-block' }}>Notification<br/><small>Email Sent</small></div>
        </div>
      </div>

      <div style={styles.archBox}>
        <div style={styles.archTitle}>🔧 Running Services</div>
        <div style={styles.serviceGrid}>
          {services.map(s => (
            <div key={s.name} style={styles.serviceChip}>
              <div style={{ ...styles.serviceName, color: s.color }}>{s.name}</div>
              <div style={styles.servicePort}>localhost{s.port}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
