import React, { useState, useEffect } from 'react';
import { inventoryAPI } from '../services/api';

const styles = {
  page: { padding: '2rem' },
  title: { fontSize: '1.6rem', fontWeight: 700, color: '#1a1a2e', marginBottom: '0.5rem' },
  sub: { color: '#666', fontSize: '0.9rem', marginBottom: '1.5rem' },
  info: { background: '#fef3c7', border: '1px solid #fcd34d', borderRadius: 8, padding: '0.8rem 1rem', marginBottom: '1.5rem', fontSize: '0.85rem', color: '#92400e' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1rem' },
  card: { background: '#fff', borderRadius: 12, padding: '1.4rem', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' },
  productId: { fontFamily: 'monospace', color: '#4f46e5', fontSize: '0.85rem', marginBottom: 6, fontWeight: 600 },
  stock: (qty) => ({ fontSize: '2rem', fontWeight: 900, color: qty > 50 ? '#059669' : qty > 10 ? '#d97706' : '#dc2626' }),
  label: { fontSize: '0.8rem', color: '#888', marginTop: 4 },
  btn: { background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 6, padding: '0.4rem 0.8rem', cursor: 'pointer', fontSize: '0.8rem', marginTop: 10 }
};

export default function Inventory() {
  const [stock, setStock] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchInventory(); }, []);

  const fetchInventory = async () => {
    try {
      const res = await inventoryAPI.getAll();
      setStock(res.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const handleAddStock = async (productId) => {
    const qty = prompt(`Add stock for ${productId}:`);
    if (!qty || isNaN(qty)) return;
    try {
      await inventoryAPI.addStock(productId, parseInt(qty));
      fetchInventory();
    } catch (e) { alert('Error adding stock'); }
  };

  return (
    <div style={styles.page}>
      <div style={styles.title}>🏭 Inventory</div>
      <div style={styles.sub}>Stock levels updated automatically via Kafka when orders are placed.</div>
      <div style={styles.info}>
        🔄 <strong>Auto-Updated:</strong> When an order is placed, the Inventory Service consumes the
        <code> OrderPlacedEvent</code> from Kafka and decrements stock — asynchronously, even if this service was temporarily down!
      </div>

      {loading ? <p>Loading inventory...</p> : (
        <div style={styles.grid}>
          {Object.entries(stock).map(([productId, qty]) => (
            <div key={productId} style={styles.card}>
              <div style={styles.productId}>{productId}</div>
              <div style={styles.stock(qty)}>{qty}</div>
              <div style={styles.label}>units in stock</div>
              <button style={styles.btn} onClick={() => handleAddStock(productId)}>+ Add Stock</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
