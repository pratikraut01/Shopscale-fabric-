import React, { useState, useEffect } from 'react';
import { orderAPI, productAPI } from '../services/api';

const styles = {
  page: { padding: '2rem' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' },
  title: { fontSize: '1.6rem', fontWeight: 700, color: '#1a1a2e' },
  btn: { background: '#10b981', color: '#fff', border: 'none', borderRadius: 8, padding: '0.6rem 1.2rem', cursor: 'pointer', fontSize: '0.9rem', fontWeight: 600 },
  table: { width: '100%', borderCollapse: 'collapse', background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' },
  th: { background: '#f8fafc', padding: '0.9rem 1rem', textAlign: 'left', fontWeight: 700, fontSize: '0.82rem', color: '#4a5568', borderBottom: '1px solid #e2e8f0', textTransform: 'uppercase' },
  td: { padding: '0.9rem 1rem', borderBottom: '1px solid #f0f2f5', fontSize: '0.9rem' },
  badge: (status) => ({
    display: 'inline-block', borderRadius: 6, padding: '3px 10px', fontSize: '0.75rem', fontWeight: 700,
    background: status === 'PLACED' ? '#dbeafe' : status === 'CONFIRMED' ? '#d1fae5' : status === 'SHIPPED' ? '#fef3c7' : '#f0fdf4',
    color: status === 'PLACED' ? '#1d4ed8' : status === 'CONFIRMED' ? '#059669' : status === 'SHIPPED' ? '#d97706' : '#15803d'
  }),
  modal: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999 },
  modalBox: { background: '#fff', borderRadius: 16, padding: '2rem', width: '90%', maxWidth: 500 },
  input: { width: '100%', border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.6rem 0.8rem', marginBottom: '0.8rem', fontSize: '0.9rem' },
  label: { fontSize: '0.82rem', fontWeight: 600, color: '#4a5568', marginBottom: 3, display: 'block' },
  info: { background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 8, padding: '0.8rem 1rem', marginBottom: '1rem', fontSize: '0.85rem', color: '#1d4ed8' }
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ customerId: '', customerEmail: '', productId: '', quantity: 1 });

  useEffect(() => { fetchOrders(); fetchProducts(); }, []);

  const fetchOrders = async () => {
    try {
      const res = await orderAPI.getAll();
      setOrders(res.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const fetchProducts = async () => {
    try {
      const res = await productAPI.getAll();
      setProducts(res.data);
    } catch (e) { console.error(e); }
  };

  const handlePlaceOrder = async () => {
    const product = products.find(p => p.id === form.productId);
    if (!product) return alert('Select a product');
    try {
      const orderData = {
        customerId: form.customerId,
        customerEmail: form.customerEmail,
        totalAmount: product.price * form.quantity,
        items: [{
          productId: product.id,
          productName: product.name,
          quantity: parseInt(form.quantity),
          price: product.price
        }]
      };
      await orderAPI.place(orderData);
      alert('✅ Order placed! Kafka event published to Inventory & Notification services.');
      setShowModal(false);
      fetchOrders();
    } catch (e) { alert('Error placing order'); }
  };

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h2 style={styles.title}>📦 Orders</h2>
        <button style={styles.btn} onClick={() => setShowModal(true)}>+ Place Order</button>
      </div>

      <div style={styles.info}>
        💡 When you place an order, an <strong>OrderPlacedEvent</strong> is published to <strong>Apache Kafka</strong>.
        Inventory Service and Notification Service consume this event asynchronously!
      </div>

      {loading ? <p>Loading orders...</p> : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Order #</th>
              <th style={styles.th}>Customer</th>
              <th style={styles.th}>Email</th>
              <th style={styles.th}>Amount</th>
              <th style={styles.th}>Status</th>
              <th style={styles.th}>Date</th>
            </tr>
          </thead>
          <tbody>
            {orders.length === 0 ? (
              <tr><td colSpan={6} style={{ ...styles.td, textAlign: 'center', color: '#94a3b8' }}>No orders yet. Place your first order!</td></tr>
            ) : orders.map(o => (
              <tr key={o.id}>
                <td style={styles.td}><code style={{ fontSize: '0.78rem' }}>{o.orderNumber?.slice(0, 8)}...</code></td>
                <td style={styles.td}>{o.customerId}</td>
                <td style={styles.td}>{o.customerEmail}</td>
                <td style={styles.td}><strong>₹{o.totalAmount}</strong></td>
                <td style={styles.td}><span style={styles.badge(o.status)}>{o.status}</span></td>
                <td style={styles.td}>{new Date(o.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showModal && (
        <div style={styles.modal}>
          <div style={styles.modalBox}>
            <h3 style={{ marginBottom: '1rem' }}>🛍️ Place New Order</h3>
            <label style={styles.label}>Customer ID</label>
            <input style={styles.input} value={form.customerId} onChange={e => setForm({ ...form, customerId: e.target.value })} placeholder="e.g. cust-001" />
            <label style={styles.label}>Customer Email</label>
            <input style={styles.input} value={form.customerEmail} onChange={e => setForm({ ...form, customerEmail: e.target.value })} placeholder="customer@email.com" />
            <label style={styles.label}>Select Product</label>
            <select style={styles.input} value={form.productId} onChange={e => setForm({ ...form, productId: e.target.value })}>
              <option value="">-- Select Product --</option>
              {products.map(p => <option key={p.id} value={p.id}>{p.name} — ₹{p.price}</option>)}
            </select>
            <label style={styles.label}>Quantity</label>
            <input style={styles.input} type="number" min={1} value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} />
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <button style={styles.btn} onClick={handlePlaceOrder}>🚀 Place Order</button>
              <button style={{ ...styles.btn, background: '#94a3b8' }} onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
