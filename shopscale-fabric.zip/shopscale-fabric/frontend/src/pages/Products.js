import React, { useState, useEffect } from 'react';
import { productAPI } from '../services/api';

const styles = {
  page: { padding: '2rem' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' },
  title: { fontSize: '1.6rem', fontWeight: 700, color: '#1a1a2e' },
  btn: { background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, padding: '0.6rem 1.2rem', cursor: 'pointer', fontSize: '0.9rem', fontWeight: 600 },
  btnDanger: { background: '#ef4444', color: '#fff', border: 'none', borderRadius: 6, padding: '0.4rem 0.8rem', cursor: 'pointer', fontSize: '0.8rem', marginLeft: 6 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.2rem' },
  card: { background: '#fff', borderRadius: 12, padding: '1.4rem', boxShadow: '0 2px 12px rgba(0,0,0,0.08)', transition: 'transform 0.2s' },
  cardName: { fontWeight: 700, fontSize: '1.05rem', marginBottom: 4, color: '#1a1a2e' },
  cardDesc: { fontSize: '0.85rem', color: '#666', marginBottom: 8 },
  cardPrice: { fontWeight: 700, color: '#4f46e5', fontSize: '1.1rem', marginBottom: 4 },
  cardStock: { fontSize: '0.8rem', color: '#888', marginBottom: 12 },
  badge: { display: 'inline-block', background: '#ede9fe', color: '#4f46e5', borderRadius: 6, padding: '2px 8px', fontSize: '0.75rem', fontWeight: 600 },
  modal: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 999 },
  modalBox: { background: '#fff', borderRadius: 16, padding: '2rem', width: '90%', maxWidth: 440 },
  input: { width: '100%', border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.6rem 0.8rem', marginBottom: '0.8rem', fontSize: '0.9rem' },
  label: { fontSize: '0.82rem', fontWeight: 600, color: '#4a5568', marginBottom: 3, display: 'block' },
  search: { border: '1px solid #e2e8f0', borderRadius: 8, padding: '0.5rem 1rem', width: 220, fontSize: '0.9rem' }
};

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', description: '', category: '', price: '', stock: '', imageUrl: '' });

  useEffect(() => { fetchProducts(); }, []);

  const fetchProducts = async () => {
    try {
      const res = await productAPI.getAll();
      setProducts(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    try {
      await productAPI.create({ ...form, price: parseFloat(form.price), stock: parseInt(form.stock) });
      setShowModal(false);
      setForm({ name: '', description: '', category: '', price: '', stock: '', imageUrl: '' });
      fetchProducts();
    } catch (e) { alert('Error creating product'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    try { await productAPI.delete(id); fetchProducts(); }
    catch (e) { alert('Error deleting product'); }
  };

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h2 style={styles.title}>🛒 Products</h2>
        <div style={{ display: 'flex', gap: 10 }}>
          <input style={styles.search} placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)} />
          <button style={styles.btn} onClick={() => setShowModal(true)}>+ Add Product</button>
        </div>
      </div>

      {loading ? <p>Loading products...</p> : (
        <div style={styles.grid}>
          {filtered.map(p => (
            <div key={p.id} style={styles.card}>
              <div style={styles.cardName}>{p.name}</div>
              <div style={styles.cardDesc}>{p.description}</div>
              <div style={styles.cardPrice}>₹{p.price}</div>
              <div style={styles.cardStock}>Stock: {p.stock} units</div>
              <span style={styles.badge}>{p.category}</span>
              <button style={styles.btnDanger} onClick={() => handleDelete(p.id)}>Delete</button>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div style={styles.modal}>
          <div style={styles.modalBox}>
            <h3 style={{ marginBottom: '1rem' }}>Add New Product</h3>
            {['name', 'description', 'category', 'price', 'stock', 'imageUrl'].map(f => (
              <div key={f}>
                <label style={styles.label}>{f.charAt(0).toUpperCase() + f.slice(1)}</label>
                <input style={styles.input} value={form[f]} onChange={e => setForm({ ...form, [f]: e.target.value })} placeholder={f} />
              </div>
            ))}
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <button style={styles.btn} onClick={handleCreate}>Create</button>
              <button style={{ ...styles.btn, background: '#94a3b8' }} onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
