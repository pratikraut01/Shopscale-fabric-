import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' }
});

// Add JWT token to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const productAPI = {
  getAll: () => api.get('/api/products'),
  getById: (id) => api.get(`/api/products/${id}`),
  create: (data) => api.post('/api/products', data),
  update: (id, data) => api.put(`/api/products/${id}`, data),
  delete: (id) => api.delete(`/api/products/${id}`),
  search: (name) => api.get(`/api/products/search?name=${name}`),
  getByCategory: (cat) => api.get(`/api/products/category/${cat}`)
};

export const orderAPI = {
  getAll: () => api.get('/api/orders'),
  place: (data) => api.post('/api/orders', data),
  getByNumber: (num) => api.get(`/api/orders/${num}`),
  getByCustomer: (id) => api.get(`/api/orders/customer/${id}`)
};

export const inventoryAPI = {
  getAll: () => api.get('/api/inventory'),
  getStock: (id) => api.get(`/api/inventory/${id}`),
  addStock: (id, qty) => api.post(`/api/inventory/${id}/add?quantity=${qty}`)
};

export default api;
