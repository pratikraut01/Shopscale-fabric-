package com.shopscale.inventory.event;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data
public class OrderPlacedEvent {
    private String orderNumber;
    private String customerId;
    private String customerEmail;
    private BigDecimal totalAmount;
    private List<OrderItemEvent> items;

    @Data
    public static class OrderItemEvent {
        private String productId;
        private String productName;
        private Integer quantity;
        private BigDecimal price;
    }
}
