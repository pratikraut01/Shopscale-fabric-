package com.shopscale.inventory.repository;

import lombok.RequiredArgsConstructor;
import com.shopscale.inventory.service.InventoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class InventoryController {

    private final InventoryService inventoryService;

    @GetMapping
    public ResponseEntity<Map<String, Integer>> getAllStock() {
        return ResponseEntity.ok(inventoryService.getAllStock());
    }

    @GetMapping("/{productId}")
    public ResponseEntity<Integer> getStock(@PathVariable String productId) {
        return ResponseEntity.ok(inventoryService.getStock(productId));
    }

    @PostMapping("/{productId}/add")
    public ResponseEntity<String> addStock(@PathVariable String productId,
                                            @RequestParam int quantity) {
        inventoryService.addStock(productId, quantity);
        return ResponseEntity.ok("Stock updated successfully");
    }
}
