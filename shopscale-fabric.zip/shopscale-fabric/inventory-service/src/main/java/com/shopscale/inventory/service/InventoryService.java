package com.shopscale.inventory.service;

import com.shopscale.inventory.event.OrderPlacedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class InventoryService {

    // In-memory stock map (replace with DB in real app)
    private final Map<String, Integer> stockMap = new ConcurrentHashMap<>(new HashMap<>() {{
        put("prod-001", 100);
        put("prod-002", 50);
        put("prod-003", 200);
    }});

    @KafkaListener(topics = "order-placed", groupId = "inventory-group")
    public void consumeOrderPlacedEvent(OrderPlacedEvent event) {
        log.info("📦 [Inventory] Received OrderPlacedEvent for order: {}", event.getOrderNumber());

        event.getItems().forEach(item -> {
            String productId = item.getProductId();
            int qty = item.getQuantity();

            stockMap.compute(productId, (k, currentStock) -> {
                int stock = (currentStock != null) ? currentStock : 0;
                if (stock >= qty) {
                    log.info("✅ [Inventory] Stock updated for product: {} | Remaining: {}",
                            productId, stock - qty);
                    return stock - qty;
                } else {
                    log.warn("⚠️ [Inventory] Insufficient stock for product: {} | Available: {}", productId, stock);
                    return stock;
                }
            });
        });
    }

    public Map<String, Integer> getAllStock() {
        return stockMap;
    }

    public Integer getStock(String productId) {
        return stockMap.getOrDefault(productId, 0);
    }

    public void addStock(String productId, int quantity) {
        stockMap.merge(productId, quantity, Integer::sum);
        log.info("📈 [Inventory] Stock added for {}: +{}", productId, quantity);
    }
}
