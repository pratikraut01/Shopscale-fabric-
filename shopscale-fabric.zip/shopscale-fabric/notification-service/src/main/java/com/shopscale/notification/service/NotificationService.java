package com.shopscale.notification.service;

import com.shopscale.notification.event.OrderPlacedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class NotificationService {

    @KafkaListener(topics = "order-placed", groupId = "notification-group")
    public void consumeOrderPlacedEvent(OrderPlacedEvent event) {
        log.info("📧 [Notification] Received order event for: {}", event.getCustomerEmail());
        sendOrderConfirmationEmail(event);
    }

    private void sendOrderConfirmationEmail(OrderPlacedEvent event) {
        // In production: integrate with SendGrid / JavaMailSender / SES
        log.info("====================================================");
        log.info("📬 ORDER CONFIRMATION EMAIL");
        log.info("To: {}", event.getCustomerEmail());
        log.info("Subject: Your ShopScale Order #{} Confirmed!", event.getOrderNumber());
        log.info("----------------------------------------------------");
        log.info("Dear Customer {},", event.getCustomerId());
        log.info("Your order has been successfully placed!");
        log.info("Order Number : {}", event.getOrderNumber());
        log.info("Total Amount : ₹{}", event.getTotalAmount());
        log.info("Items ordered:");
        event.getItems().forEach(item ->
            log.info("  - {} x{} @ ₹{}", item.getProductName(), item.getQuantity(), item.getPrice())
        );
        log.info("Thank you for shopping with ShopScale Fabric!");
        log.info("====================================================");
    }
}
