package com.shopscale.order.service;

import com.shopscale.order.event.OrderPlacedEvent;
import com.shopscale.order.model.Order;
import com.shopscale.order.model.OrderItem;
import com.shopscale.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, OrderPlacedEvent> kafkaTemplate;

    private static final String ORDER_TOPIC = "order-placed";

    @Transactional
    public Order placeOrder(Order order) {
        order.setOrderNumber(UUID.randomUUID().toString());
        Order savedOrder = orderRepository.save(order);

        // Publish event to Kafka
        OrderPlacedEvent event = buildEvent(savedOrder);
        kafkaTemplate.send(ORDER_TOPIC, event);

        log.info("✅ Order placed: {} | Kafka event published to topic: {}",
                savedOrder.getOrderNumber(), ORDER_TOPIC);

        return savedOrder;
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderByNumber(String orderNumber) {
        return orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderNumber));
    }

    public List<Order> getOrdersByCustomer(String customerId) {
        return orderRepository.findByCustomerId(customerId);
    }

    public Order updateStatus(Long id, Order.OrderStatus status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found: " + id));
        order.setStatus(status);
        return orderRepository.save(order);
    }

    private OrderPlacedEvent buildEvent(Order order) {
        List<OrderPlacedEvent.OrderItemEvent> itemEvents = order.getItems().stream()
                .map(item -> OrderPlacedEvent.OrderItemEvent.builder()
                        .productId(item.getProductId())
                        .productName(item.getProductName())
                        .quantity(item.getQuantity())
                        .price(item.getPrice())
                        .build())
                .collect(Collectors.toList());

        return OrderPlacedEvent.builder()
                .orderNumber(order.getOrderNumber())
                .customerId(order.getCustomerId())
                .customerEmail(order.getCustomerEmail())
                .totalAmount(order.getTotalAmount())
                .items(itemEvents)
                .build();
    }
}
